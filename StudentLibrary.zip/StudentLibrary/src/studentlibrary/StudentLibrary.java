package studentlibrary;

public class StudentLibrary {

    public static void main(String[] args) {

        LibraryCntl cntl = new LibraryCntl();

    }
}
