package studentlibrary;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class LibraryList {

    ArrayList<Book> libraryList = new ArrayList<>();

    private void addBookToList() {

        Book book1 = new Book("Jungle Book", "Rudyard Kipling", "Children's literature");
        Book book2 = new Book("Gone With the Wind", "Margaret Mitchell", "Historical Fiction");
        Book book3 = new Book("Fault in Our Stars", "John Green", "Young adult fiction");
        Book book4 = new Book("Harry Potter and The Chamber of Secrets", "J. K. Rowling", "Fantasy Fiction");
        Book book5 = new Book("Harry Potter and The Prisoner of Azkaban", "J. K. Rowling", "Fantasy Fiction");
        Book book6 = new Book("Harry Potter and The Goblet of Fire", "J. K. Rowling", "Fantasy Fiction");
        Book book7 = new Book("Harry Potter and The Half-Blood Prince", "J. K. Rowling", "Fantasy Fiction");
        Book book8 = new Book("Harry Potter and The Deathly Hallows", "J. K. Rowling", "Fantasy Fiction");
        Book book9 = new Book("Adventures of Huckleberry Fin", "Mark Twain", "Picaresque Fiction");
        Book book10 = new Book("Mice of Men", "John Steinbeck", "Novella");
        Book book11 = new Book("The Kite Runner", "Khaled Hosseini", "Historical fiction");
        Book book12 = new Book("The Great Gatsby", "F. Scott Fizgerald", "Historical Fiction");
        Book book13 = new Book("Alice's Adventures in Wonderland", "Lewis Carroll", "Fantasy");
        Book book14 = new Book("Water for Elephants", "Sara Gruen", "Romance Novel");
        Book book15 = new Book("The Circle", "Dave Eggers", "Dystopian");
        Book book16 = new Book("The Hunger Games", "Suzanne Collins", "Dystopian");

        libraryList.add(book1);
        libraryList.add(book2);
        libraryList.add(book3);
        libraryList.add(book4);
        libraryList.add(book5);
        libraryList.add(book6);
        libraryList.add(book7);
        libraryList.add(book8);
        libraryList.add(book9);
        libraryList.add(book10);
        libraryList.add(book11);
        libraryList.add(book12);
        libraryList.add(book13);
        libraryList.add(book14);
        libraryList.add(book15);
        libraryList.add(book16);

    }

    public Map<String, ArrayList<Book>> myMap() {

        ArrayList<Book> jamiesList = new ArrayList<>();
        jamiesList.add(libraryList.get(0 - 2));

        ArrayList<Book> alexsList = new ArrayList<>();
        alexsList.add(libraryList.get(3 - 7));

        ArrayList<Book> bethsList = new ArrayList<>();
        bethsList.add(libraryList.get(8 - 11));

        ArrayList<Book> georgesList = new ArrayList<>();
        georgesList.add(libraryList.get(12 - 15));

        Map<String, ArrayList<Book>> myMap = new HashMap<>();

        myMap.put("Jamie", jamiesList);
        myMap.put("Alex", alexsList);
        myMap.put("Beth", bethsList);
        myMap.put("George", georgesList);

        return myMap;
    }

    public LibraryList() {
        libraryList = new ArrayList<>();
        LibraryList.this.addBookToList();
    }

    public void addBookToList(Book library) {
        getLibraryList().add(library);
    }

    public void updateLibrary(Book library, int row) {
        libraryList.set(row, library);
    }

    public void removeBook(int row) {
        libraryList.remove(row);
    }

    public ArrayList<Book> getLibraryList() {
        return libraryList;
    }

    public Book getDetailValue(int bookInfo) {
        return getLibraryList().get(bookInfo);
    }

    public int getDetails() {
        return libraryList.size();
    }

    public Book getRow(int rowIndex) {
        return libraryList.get(rowIndex);
    }
}
