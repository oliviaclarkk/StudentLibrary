package studentlibrary;

import javax.swing.table.AbstractTableModel;

public class LibraryTableModel extends AbstractTableModel {

    private final String[] columnNames = {"Title", "Author", "Genre"};
    private final LibraryList libraryList;

    public LibraryTableModel(LibraryList newLibraryList) {
        libraryList = newLibraryList;
    }

    @Override
    public int getRowCount() {
        return libraryList.getDetails();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int index) {
        return columnNames[index];
    }

    @Override
    public Object getValueAt(int row, int col) {
        switch (col) {
            case 0:
                return (Object) libraryList.getRow(row).getTitle();
            case 1:
                return (Object) libraryList.getRow(row).getAuthor();
            case 2:
                return (Object) libraryList.getRow(row).getGenre();
            default:
                return null;
        }
    }
}
