package studentlibrary;

import java.util.ArrayList;
import java.util.Map;

public class LibraryCntl {

    private final LibraryList libraryList = new LibraryList();
    private final LibraryTableModel libraryTableModel = new LibraryTableModel(libraryList);
    private final LibraryListUI libraryListUI;
    private LibraryDetail libraryDetail;

    public LibraryCntl() {
        libraryListUI = new LibraryListUI(this, libraryList);
        libraryListUI.setVisible(Boolean.TRUE);
    }

    public Map<String, ArrayList<Book>> getMyMap() {
        return libraryList.myMap();
    }

    public LibraryTableModel getLibraryTableModel() {
        return libraryTableModel;
    }

    public void getLibraryDetail(int selectedRow) {
        libraryDetail = new LibraryDetail(this, selectedRow);
        libraryDetail.setVisible(true);
    }

    public void updateLibrary(Book library, int row) {
        if (row >= 0) {
            libraryList.updateLibrary(library, row);
        } else {
            libraryList.addBookToList(library);
        }
        libraryListUI.initComponents();
        restoreLibraryListUI();
    }

    public void deleteBook(int row) {
        if (row >= 0) {
            libraryList.removeBook(row);
            libraryListUI.initComponents();
            libraryListUI.setVisible(true);
        }
    }

    public void restoreLibraryListUI() {
        libraryDetail.setVisible(false);
        libraryListUI.setVisible(true);
        libraryDetail.dispose();
    }

    public Book getLibrary(int row) {
        return libraryList.getDetailValue(row);
    }
}
