package studentlibrary;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public final class LibraryListUI extends JFrame {

    private final JTextField firstNameDisplayValue = new JTextField(15);
    private final LibraryCntl libraryCntl;
    private final LibraryList libraryList;
    private JPanel instrumentPanel;
    private JPanel tablePanel;
    private JPanel buttonPanel;
    private JTable libraryTable;

    public LibraryListUI(LibraryCntl newLibraryCntl, LibraryList newLibraryList) {

        libraryCntl = newLibraryCntl;
        libraryList = newLibraryList;
        initComponents();
        setFieldView();
    }

    public void initComponents() {

        setTitle("Student Library");
        setSize(500, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        instrumentPanel = new JPanel(new GridLayout(5, 1));
        instrumentPanel.add(new JLabel("First Name"));
        instrumentPanel.add(firstNameDisplayValue);
        instrumentPanel.add(new JLabel("Students: Jamie, George, Alex, Beth"));

        tablePanel = new JPanel();
        buttonPanel = new JPanel(new GridLayout(1, 4));
        libraryTable = new JTable(new LibraryTableModel(libraryList));
        libraryTable.getColumnModel().getColumn(0).setPreferredWidth(100);
        libraryTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        libraryTable.getColumnModel().getColumn(2).setPreferredWidth(100);

        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(new SearchButton());

        JButton newButton = new JButton("New Book");
        newButton.addActionListener(new NewButton());

        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new DeleteButton());

        JButton doneButton = new JButton("Done");
        doneButton.addActionListener(new DoneButton());

        buttonPanel.add(searchButton);
        buttonPanel.add(newButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(doneButton);

        JScrollPane tableScroller = new JScrollPane(libraryTable);
        libraryTable.setFillsViewportHeight(true);
        tableScroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tableScroller.setPreferredSize(new Dimension(350, 300));
        tablePanel.setPreferredSize(new Dimension(350, 300));
        tablePanel.add(tableScroller);

        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(instrumentPanel, BorderLayout.NORTH);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        getContentPane().add(tablePanel, BorderLayout.CENTER);

    }

    private void setFieldView() {
        firstNameDisplayValue.setText("Enter a Student");
    }

    public class SearchButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            if (firstNameDisplayValue.getText().toUpperCase().equals("Jamie".toUpperCase())) {
                System.out.println("The books below are for " + firstNameDisplayValue.getText() + ":");
                libraryTable.addRowSelectionInterval(0, 2);
                System.out.println(libraryList.libraryList.get(0).getTitle() + ", " + libraryList.libraryList.get(0).getAuthor() + ", " + libraryList.libraryList.get(0).getGenre());
                System.out.println(libraryList.libraryList.get(1).getTitle() + ", " + libraryList.libraryList.get(1).getAuthor() + ", " + libraryList.libraryList.get(1).getGenre());
                System.out.println(libraryList.libraryList.get(2).getTitle() + ", " + libraryList.libraryList.get(2).getAuthor() + ", " + libraryList.libraryList.get(2).getGenre());

            } else if (firstNameDisplayValue.getText().toUpperCase().equals("George".toUpperCase())) {
                System.out.println("The books below are for " + firstNameDisplayValue.getText() + ":");
                libraryTable.addRowSelectionInterval(3, 7);
                System.out.println(libraryList.libraryList.get(3).getTitle() + ", " + libraryList.libraryList.get(3).getAuthor() + ", " + libraryList.libraryList.get(3).getGenre());
                System.out.println(libraryList.libraryList.get(4).getTitle() + ", " + libraryList.libraryList.get(4).getAuthor() + ", " + libraryList.libraryList.get(4).getGenre());
                System.out.println(libraryList.libraryList.get(5).getTitle() + ", " + libraryList.libraryList.get(5).getAuthor() + ", " + libraryList.libraryList.get(5).getGenre());
                System.out.println(libraryList.libraryList.get(6).getTitle() + ", " + libraryList.libraryList.get(6).getAuthor() + ", " + libraryList.libraryList.get(6).getGenre());
                System.out.println(libraryList.libraryList.get(7).getTitle() + ", " + libraryList.libraryList.get(7).getAuthor() + ", " + libraryList.libraryList.get(7).getGenre());

            } else if (firstNameDisplayValue.getText().toUpperCase().equals("Alex".toUpperCase())) {
                System.out.println("The books below are for " + firstNameDisplayValue.getText() + ":");
                libraryTable.addRowSelectionInterval(8, 11);
                System.out.println(libraryList.libraryList.get(8).getTitle() + ", " + libraryList.libraryList.get(8).getAuthor() + ", " + libraryList.libraryList.get(8).getGenre());
                System.out.println(libraryList.libraryList.get(9).getTitle() + ", " + libraryList.libraryList.get(9).getAuthor() + ", " + libraryList.libraryList.get(9).getGenre());
                System.out.println(libraryList.libraryList.get(10).getTitle() + ", " + libraryList.libraryList.get(10).getAuthor() + ", " + libraryList.libraryList.get(10).getGenre());
                System.out.println(libraryList.libraryList.get(11).getTitle() + ", " + libraryList.libraryList.get(11).getAuthor() + ", " + libraryList.libraryList.get(11).getGenre());

            } else if (firstNameDisplayValue.getText().toUpperCase().equals("Beth".toUpperCase())) {
                System.out.println("The books below are for " + firstNameDisplayValue.getText() + ":");
                libraryTable.addRowSelectionInterval(12, 15);
                System.out.println(libraryList.libraryList.get(12).getTitle() + ", " + libraryList.libraryList.get(12).getAuthor() + ", " + libraryList.libraryList.get(12).getGenre());
                System.out.println(libraryList.libraryList.get(13).getTitle() + ", " + libraryList.libraryList.get(13).getAuthor() + ", " + libraryList.libraryList.get(13).getGenre());
                System.out.println(libraryList.libraryList.get(14).getTitle() + ", " + libraryList.libraryList.get(14).getAuthor() + ", " + libraryList.libraryList.get(14).getGenre());
                System.out.println(libraryList.libraryList.get(15).getTitle() + ", " + libraryList.libraryList.get(15).getAuthor() + ", " + libraryList.libraryList.get(15).getGenre());
            }
        }
    }

    public class DeleteButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            int selectedTableRow = libraryTable.getSelectedRow();
            int selectedModelRow = libraryTable.convertRowIndexToModel(selectedTableRow);
            libraryCntl.deleteBook(selectedModelRow);
        }
    }

    public class NewButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            libraryList.getLibraryList().add(new Book("", "", ""));
            libraryCntl.getLibraryDetail(libraryList.getLibraryList().size() - 1);
        }
    }

    public class DoneButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            dispose();
            System.exit(0);
        }
    }
}
