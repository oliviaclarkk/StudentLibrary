package studentlibrary;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public final class LibraryDetail extends JFrame {

    private final LibraryCntl libraryCntl;
    private final Book selectedLibrary;
    private final int selectedRow;
    private final JTextField titleText = new JTextField(150);
    private final JTextField authorText = new JTextField(150);
    private final JTextField genreText = new JTextField(150);

    public LibraryDetail(LibraryCntl cntl, int row) {
        libraryCntl = cntl;
        selectedRow = row;
        if (row < 0) {
            selectedLibrary = libraryCntl.getLibrary(row);
        } else {
            selectedLibrary = libraryCntl.getLibrary(selectedRow);
        }
        initComponents();
        parseSelectedLibrary();
    }

    public void initComponents() {

        setTitle("Student Detail");
        setSize(280, 140);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel detailPanel = new JPanel(new GridLayout(3, 2));

        JPanel buttonPanel = new JPanel(new GridLayout(1, 2));

        JButton saveButton = new JButton("Save");
        JButton cancelButton = new JButton("Cancel");
        saveButton.addActionListener(new SaveButton());
        cancelButton.addActionListener(new CancelButton());
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        JLabel titleLabel = new JLabel("Title:");
        detailPanel.add(titleLabel);
        detailPanel.add(titleText);

        JLabel authorLabel = new JLabel("Author:");
        detailPanel.add(authorLabel);
        detailPanel.add(authorText);

        JLabel genreLabel = new JLabel("Genre:");
        detailPanel.add(genreLabel);
        detailPanel.add(genreText);

        setContentPane(new JPanel(new BorderLayout()));
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        getContentPane().add(detailPanel, BorderLayout.CENTER);

    }

    public class SaveButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent evt) {
            selectedLibrary.setTitle(titleText.getText());
            selectedLibrary.setAuthor(authorText.getText());
            selectedLibrary.setGenre(genreText.getText());
            libraryCntl.updateLibrary(selectedLibrary, selectedRow);
        }
    }

    public class CancelButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent evt) {
            libraryCntl.restoreLibraryListUI();
        }
    }

    public void parseSelectedLibrary() {
        titleText.setText(selectedLibrary.getTitle());
        authorText.setText(selectedLibrary.getAuthor());
        genreText.setText(selectedLibrary.getGenre());
    }
}
